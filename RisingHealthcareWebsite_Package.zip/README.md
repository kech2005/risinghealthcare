# Rising Healthcare Agency Website

This repository contains the official website for **Rising Healthcare Agency**.

## 🌐 Live Features

- NHS-aligned branding and colors
- Mobile-friendly and responsive design
- Services include NEMT, mental healthcare transport, secure placement, and mobility support
- Contact section with interactive links and Google Maps integration

## 📄 How to Publish

### GitHub Pages
1. Upload `index.html` to a public repository.
2. Go to Repository → Settings → Pages.
3. Set source to `main` branch and root.
4. Access your live site at `https://yourusername.github.io/repo-name`.

### Netlify
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop this `index.html` file.
3. Share your site using the Netlify URL provided.

## 📬 Contact
- Email: Risinghealthcare@aol.com
- Website: [www.risingheathcare.co.uk](https://www.risingheathcare.co.uk)
